//
// Created by Victor NAGY on 23/01/2020.
//

#ifndef SERVERS_AND_DRONES_COLOR_H
#define SERVERS_AND_DRONES_COLOR_H

const float BLACK[4]={0.0,0.0,0.0,1.0f};
const float GREY[4]={0.75f,0.75f,0.75f,1.0f};
const float RED[4]={1.0f,0.0,0.0,1.0f};
const float ORANGE[4]={1.0f,0.27f,0.0,1.0f};
const float YELLOW[4]={1.0f,1.0f,0.0,1.0f};
const float GREEN[4]={0.0,1.0f,0.0,1.0f};
const float BLUE[4]={0.0,0.0,1.0f,1.0f};

#endif //SERVERS_AND_DRONES_COLOR_H
